"""H2: Freitag. 2 Stunden Belege. (Belege erfassen fuers Steuerbuero)"""
import json
from common import scene, end_scene, write_project, CURSOR_SVG

# Schnipsel im Hook: (Lieferant, Datum, Betrag, Rasterspalte, Rasterzeile, dx, dy, Drehung)
SLIPS = [("Tankstelle Elbbrücken", "02.10.", "84,60", 0, 0, -12, 18, -7),
         ("Baumarkt Wandsbek", "03.10.", "132,45", 1, 0, -18, 30, 8),
         ("Parkhaus Altstadt", "06.10.", "12,00", 2, 0, -14, -8, -6),
         ("Elektro-Großhandel Nord", "07.10.", "418,90", 0, 1, 20, -16, 10),
         ("Büro-Service HH", "09.10.", "59,00", 1, 1, -22, 16, -11),
         ("Tankstelle Elbbrücken", "10.10.", "91,20", 2, 1, -16, 10, 7)]
GX = [88, 367, 646]
GY = [815, 1050]
SORTED = [1, 3, 5]          # diese drei werden nacheinander zurechtgerueckt
MOVES = [0.05, 1.00, 1.95]  # Start der Bewegung, Dauer 0,75 s

slips_html = []
for i, (sup, dat, amt, c, r, dx, dy, rot) in enumerate(SLIPS):
    slips_html.append(
        f'<div id="h2a-s{i}" class="paper" style="left:{GX[c]}px; top:{GY[r]}px; width:270px; height:210px; padding:18px 22px;">'
        f'<div style="font-weight:700; font-size:28px; line-height:1.1; height:96px;">{sup}</div>'
        f'<div style="display:flex; justify-content:space-between; margin-top:20px; font-family:\'JetBrains Mono\', monospace; font-size:30px;">'
        f'<span>{dat}</span><span style="font-weight:700;">{amt}</span></div>'
        f'<div id="h2a-t{i}" class="abs" style="right:12px; top:12px; width:44px; height:44px; border-radius:22px; background:#142031; color:#EDF4FF; font-size:28px; display:flex; align-items:center; justify-content:center; opacity:0;">✓</div></div>')

s1_body = f"""
    <div id="h2a-all" class="abs" style="left:0; top:0; width:1080px; height:1920px;">
      <div id="h2a-clock" class="clock"><i></i><span id="h2a-time">14:00</span></div>
      <div id="h2a-l1" class="hook white" style="top:310px; font-size:110px;">FREITAG.</div>
      <div id="h2a-l2" class="hook blue" style="top:424px; font-size:110px;">2 STUNDEN</div>
      <div id="h2a-l3" class="hook blue" style="top:538px; font-size:110px;">BELEGE.</div>
      <div id="h2a-l4" class="hook red" style="top:664px; font-size:56px; font-weight:600;">Das Steuerbüro wartet.</div>
      <div id="h2a-prog" class="abs" style="left:88px; top:1300px; font-size:44px; font-weight:500;"><span id="h2a-n">0</span> von 23 sortiert</div>
      <div class="bar" style="top:1372px;"><b id="h2a-bar"></b></div>
      {''.join(slips_html)}
    </div>
"""

s1 = []
for i, (sup, dat, amt, c, r, dx, dy, rot) in enumerate(SLIPS):
    dd = 0.04 if i == SORTED[0] else 0.5
    s1.append(f'    tl.fromTo("#h2a-s{i}", {{x:{dx}, y:{dy + 18}, rotation:{rot}}}, {{x:{dx}, y:{dy}, rotation:{rot}, duration:{dd}, ease:"power3.out"}}, 0);')
for k, (si, t) in enumerate(zip(SORTED, MOVES)):
    s1.append(f'    tl.to("#h2a-s{si}", {{x:0, y:0, rotation:0, duration:0.75, ease:"power3.inOut"}}, {t});')
    s1.append(f'    tl.to("#h2a-s{si}", {{boxShadow:"0 0 0 4px #A7B4C8", scale:1.03, duration:0.2}}, {t + 0.6:.2f});')
    s1.append(f'    tl.fromTo("#h2a-t{si}", {{opacity:0, scale:0.4}}, {{opacity:1, scale:1, duration:0.25, ease:"expo.out"}}, {t + 0.7:.2f});')
land = [round(t + 0.75, 2) for t in MOVES]
times = ["14:05", "14:10", "14:15"]
for k, t in enumerate(land):
    s1.append(f'    tl.set("#h2a-n", {{textContent:"{k+1}"}}, {t}); tl.set("#h2a-time", {{textContent:"{times[k]}"}}, {t});')
    s1.append(f'    tl.to("#h2a-bar", {{scaleX:{(k+1)/23:.3f}, duration:0.3, ease:"power3.out"}}, {t});')
    s1.append(f'    tl.to("#h2a-clock", {{scale:1.08, duration:0.05}}, {t}); tl.to("#h2a-clock", {{scale:1, duration:0.25, ease:"power3.out"}}, {t + 0.06:.2f});')
s1 += [
    '    tl.fromTo("#h2a-bar", {scaleX:0}, {scaleX:0.02, duration:0.3, ease:"power3.out"}, 0); tl.set("#h2a-clock", {scale:1}, 0);',
    '    tl.fromTo("#h2a-l1", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0);',
    '    tl.fromTo("#h2a-l2", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0.04);',
    '    tl.fromTo("#h2a-l3", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0.08);',
    '    tl.to("#h2a-all", {y:-220, opacity:0, duration:0.18, ease:"power3.in"}, 2.80);',
]

# ---------- Szene 2 ----------
ROWS = [("02.10.", "Tankstelle Elbbrücken", "84,60"), ("03.10.", "Baumarkt Wandsbek", "132,45"),
        ("06.10.", "Parkhaus Altstadt", "12,00"), ("07.10.", "Elektro-Großhandel Nord", "418,90"),
        ("09.10.", "Büro-Service HH", "59,00"), ("10.10.", "Tankstelle Elbbrücken", "91,20")]
FROM = [(-220, 520, -14), (140, 600, 10), (260, 480, -8), (-120, 640, 15), (60, 560, -12), (220, 700, 7)]
rows = []
for i, (d, s, b) in enumerate(ROWS):
    rows.append(f'<div id="h2b-r{i}" class="row" style="top:{70 + i*76}px; height:76px; font-size:36px;">'
                f'<span class="mono" style="width:112px; font-size:30px;">{d}</span>'
                f'<span class="a">{s}</span><span class="b">{b}</span>'
                f'<span id="h2b-c{i}" style="width:44px; height:44px; border-radius:22px; border:2px solid #2B3B52; margin-left:18px; '
                f'display:flex; align-items:center; justify-content:center; font-size:28px; color:#fff;"><span id="h2b-k{i}" style="opacity:0">✓</span></span></div>')

s2_body = f"""
    <div id="h2b-title" class="hook blue" style="top:220px; font-size:110px;">Automatisch.</div>
    <div id="h2b-cw" class="abs" style="left:88px; top:372px; width:828px; white-space:nowrap;">
      <span class="mono" style="font-size:60px;"><span id="h2b-cnt">0</span> von 23</span>
      <span class="muted" style="font-size:40px; margin-left:16px;">erfasst</span>
    </div>
    <div id="h2b-list" class="card" style="left:88px; top:480px; width:828px; height:658px;" data-layout-allow-overflow>
      <div class="row muted" style="top:0; font-size:28px; background:#172232;"><span style="width:112px;">Datum</span><span class="a">Lieferant</span><span style="margin-right:62px;">Betrag</span></div>
      {''.join(rows)}
      <div id="h2b-more" class="row muted" style="top:526px; height:56px; font-size:30px;"><span class="a">+ 17 weitere Belege</span></div>
      <div id="h2b-sum" class="row" style="top:582px; height:76px; border-bottom:none; font-weight:700; background:#172232;"><span class="a">23 Belege</span><span class="b" style="font-size:34px; margin-right:62px;">1.482,60 €</span></div>
    </div>
    <div id="h2b-btn" class="btn" style="left:88px; top:1170px; width:470px; opacity:0;">Alle freigeben</div>
    <div id="h2b-exp" class="badge" style="left:88px; top:1292px; width:560px; opacity:0;">Export CSV fürs Steuerbüro</div>
    <div id="h2b-ring" class="ring" style="left:278px; top:1173px; opacity:0;"></div>
    <div id="h2b-cur" class="abs" style="left:0; top:0; width:56px; height:56px;">{CURSOR_SVG}</div>
"""

row_t = [0.50 + i * 0.14 for i in range(6)]
fast_t = [1.30 + k * 0.065 for k in range(17)]  # Zaehler 7 bis 23
s2 = [
    '    tl.fromTo("#h2b-title", {opacity:1, scale:1.14, transformOrigin:"0% 50%"}, {opacity:1, scale:1, duration:0.4, ease:"expo.out"}, 0);',
    '    tl.fromTo("#h2b-cw", {opacity:0, x:40}, {opacity:1, x:0, duration:0.3, ease:"power3.out"}, 0.10);',
    '    tl.fromTo("#h2b-list", {opacity:0, y:60}, {opacity:1, y:0, duration:0.35, ease:"power3.out"}, 0.16);',
]
for i, t in enumerate(row_t):
    fx, fy, fr = FROM[i]
    s2.append(f'    tl.fromTo("#h2b-r{i}", {{opacity:0, x:{fx}, y:{fy}, rotation:{fr}, backgroundColor:"#EDF4FF", color:"#142031"}}, '
              f'{{opacity:1, x:0, y:0, rotation:0, duration:0.32, ease:"power3.out"}}, {t:.2f});')
    s2.append(f'    tl.to("#h2b-r{i}", {{backgroundColor:"rgba(17,24,36,0)", color:"#F5F7FA", duration:0.25}}, {t + 0.28:.2f});')
    s2.append(f'    tl.set("#h2b-cnt", {{textContent:"{i+1}"}}, {t + 0.3:.2f});')
for k, t in enumerate(fast_t):
    s2.append(f'    tl.set("#h2b-cnt", {{textContent:"{7+k}"}}, {t:.3f});')
s2 += [
    '    tl.fromTo("#h2b-more", {opacity:0}, {opacity:1, duration:0.25}, 1.35);',
    '    tl.fromTo("#h2b-sum", {opacity:0}, {opacity:1, duration:0.25, ease:"power3.out"}, 2.55);',
    '    tl.fromTo("#h2b-btn", {opacity:0, y:30, scale:1, boxShadow:"0 0 0px rgba(85,152,255,0)"}, {opacity:1, y:0, duration:0.3, ease:"power3.out"}, 2.55);',
    '    tl.fromTo("#h2b-cur", {x:860, y:1380, opacity:0}, {x:300, y:1202, opacity:1, duration:0.36, ease:"power3.out"}, 2.72);',
    '    tl.fromTo("#h2b-ring", {opacity:1, scale:0.3}, {opacity:0, scale:1.5, duration:0.35, ease:"power3.out", immediateRender:false}, 3.10);',
    '    tl.to("#h2b-btn", {scale:0.96, boxShadow:"0 0 34px rgba(85,152,255,0.9)", duration:0.08}, 3.10);',
    '    tl.to("#h2b-btn", {scale:1, boxShadow:"0 0 0px rgba(85,152,255,0)", duration:0.2}, 3.20);',
    *[f'    tl.to("#h2b-c{i}", {{backgroundColor:"#317BEE", borderColor:"#317BEE", duration:0.12}}, {3.16 + i*0.035:.3f});' for i in range(6)],
    *[f'    tl.to("#h2b-k{i}", {{opacity:1, duration:0.12}}, {3.16 + i*0.035:.3f});' for i in range(6)],
    '    tl.fromTo("#h2b-exp", {opacity:0, y:16}, {opacity:1, y:0, duration:0.3, ease:"power3.out"}, 3.40);',
    '    tl.to("#h2b-cur", {opacity:0, duration:0.2}, 3.70);',
]

s3_body, s3_script = end_scene("h2c", "Freitag ist wieder Feierabend.")

files = {
    "h2a": scene("h2a", 3.0, s1_body, "\n".join(s1)),
    "h2b": scene("h2b", 4.5, s2_body, "\n".join(s2)),
    "h2c": scene("h2c", 1.5, s3_body, s3_script),
}
d = write_project("h2", files, [("h2a", 0, 3.0), ("h2b", 3.0, 4.5), ("h2c", 7.5, 1.5)])

events = {
    "rustle": [0.0] + MOVES,
    "clock": [0.0, 0.5, 1.0, 1.5, 2.0, 2.5],
    "tick_big": land,
    "whoosh": [2.80],
    "thunk": [[3.0, 80]],
    "read": [round(3.0 + t + 0.3, 3) for t in row_t] + [round(3.0 + t, 3) for t in fast_t],
    "glass": [[3.0 + fast_t[-1], 84]],
    "soft": [3.0 + 2.55],
    "click": [6.10],
    "thunk2": [[6.10, 70]],
    "chord": [[6.18, [72, 76, 79], 0.6]],
    "endchord": [[7.50, [67, 72, 76], 1.4]],
}
json.dump(events, open(f"{d}/assets/events.json", "w"), indent=1)
print(d)
