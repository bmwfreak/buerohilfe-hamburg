"""H3: Dieselben Zahlen. Zum dritten Mal. (einmal eingeben, mehrfach nutzen)"""
import json
from common import scene, end_scene, write_project, CURSOR_SVG

TXT = "Bad sanieren · 14 m² · Fliesen 60x60"
CARDS = [("Anfrage (Mail)", 800), ("Excel-Liste", 975), ("Angebot", 1150)]
TYPE = [(0.05, 0.85), (0.95, 1.75), (1.85, 2.65)]

cards_html = []
for k, (label, top) in enumerate(CARDS):
    cards_html.append(
        f'<div id="h3a-c{k}" class="card" style="left:88px; top:{top}px; width:828px; height:150px; padding:20px 28px;">'
        f'<div class="muted" style="font-size:30px;">{label}</div>'
        f'<div style="font-size:36px; margin-top:14px; white-space:nowrap;"><span id="h3a-t{k}"></span>'
        f'<span style="display:inline-block; width:4px; height:40px; background:#FF5A4D; margin-left:4px; vertical-align:-6px;"></span></div></div>')

s1_body = f"""
    <div id="h3a-all" class="abs" style="left:0; top:0; width:1080px; height:1920px;">
      <div id="h3a-l1" class="hook white" style="top:296px; font-size:110px;">DIESELBEN</div>
      <div id="h3a-l2" class="hook white" style="top:410px; font-size:110px;">ZAHLEN.</div>
      <div id="h3a-l3" class="hook red" style="top:540px; font-size:110px;">ZUM DRITTEN</div>
      <div id="h3a-l4" class="hook red" style="top:654px; font-size:110px;">MAL.</div>
      {''.join(cards_html)}
      <div id="h3a-x" class="abs" style="left:796px; top:1110px; width:120px; height:96px; border-radius:48px; background:#FF5A4D; color:#fff; font-size:50px; font-weight:700; display:flex; align-items:center; justify-content:center; opacity:0;">3×</div>
    </div>
"""

s1 = ['    tl.fromTo("#h3a-l1", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0);',
      '    tl.fromTo("#h3a-l2", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0.04);',
      '    tl.fromTo("#h3a-l3", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0.08);',
      '    tl.fromTo("#h3a-l4", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0.12);']
clacks = []
for k, (a, b) in enumerate(TYPE):
    s1.append(f'    tl.set("#h3a-t{k}", {{textContent:""}}, 0);')
    s1.append(f'    tl.to("#h3a-c{k}", {{borderColor:"#FF5A4D", duration:0.1}}, {a});')
    if k > 0:
        s1.append(f'    tl.to("#h3a-c{k-1}", {{borderColor:"#2B3B52", duration:0.1}}, {a});')
    n = len(TXT)
    for i in range(1, n + 1):
        t = a + (b - a) * (i - 1) / (n - 1)
        s1.append(f'    tl.set("#h3a-t{k}", {{textContent:{json.dumps(TXT[:i])}}}, {t:.3f});')
        if TXT[i-1] != " " and i % 2 == 0:
            clacks.append(round(t, 3))
s1 += ['    tl.fromTo("#h3a-x", {opacity:0, scale:0.5}, {opacity:1, scale:1, duration:0.3, ease:"expo.out"}, 2.55);',
       '    tl.to("#h3a-all", {y:-220, opacity:0, duration:0.18, ease:"power3.in"}, 2.80);']

# ---------- Szene 2: Einmal reicht ----------
FIELDS = [("Kunde", "Familie Petersen"), ("Leistung", "Bad sanieren"), ("Fläche", "14 m²"), ("Material", "Fliesen 60x60")]
fhtml = []
for i, (k, v) in enumerate(FIELDS):
    x = 28 + (i % 2) * 400
    y = 70 + (i // 2) * 100
    fhtml.append(f'<div id="h3b-f{i}" class="abs" style="left:{x}px; top:{y}px; width:376px; height:86px; border-radius:14px; border:2px solid #2B3B52; padding:8px 16px;">'
                 f'<div class="muted" style="font-size:28px;">{k}</div><div id="h3b-v{i}" style="font-size:34px; font-weight:500; opacity:0; white-space:nowrap;">{v}</div></div>')
POS = [("Fliesen 60x60, 14 m²", "812,00"), ("Verlegung, 14 m²", "1.176,00"), ("Abdichtung, pauschal", "390,00")]
phtml = []
for i, (a, b) in enumerate(POS):
    phtml.append(f'<div id="h3b-p{i}" class="row" style="top:{70 + i*72}px; height:72px; font-size:34px; opacity:0;"><span class="a">{a}</span><span class="b" style="font-size:32px;">{b} €</span></div>')

s2_body = f"""
    <div id="h3b-title" class="hook blue" style="top:220px; font-size:100px;">Einmal reicht.</div>
    <div id="h3b-req" class="card" style="left:88px; top:360px; width:828px; height:290px; border-color:#5598FF;">
      <div style="position:absolute; left:28px; top:18px; font-size:30px; font-weight:700;">Anfrage</div>
      {''.join(fhtml)}
    </div>
    <div id="h3b-l1" class="abs" style="left:496px; top:650px; width:6px; height:40px; background:#5598FF; transform-origin:50% 0%;"></div>
    <div id="h3b-xl" class="card" style="left:88px; top:690px; width:828px; height:130px;">
      <div class="muted" style="position:absolute; left:28px; top:14px; font-size:28px;">Excel-Liste</div>
      <div class="abs" style="left:28px; top:60px; width:772px; height:56px; display:flex; gap:12px; font-size:32px; white-space:nowrap;">
        <span id="h3b-x0" style="flex:1.3; background:#172232; border-radius:10px; padding:6px 12px; opacity:0;">Petersen</span>
        <span id="h3b-x1" style="flex:1.4; background:#172232; border-radius:10px; padding:6px 12px; opacity:0;">Bad sanieren</span>
        <span id="h3b-x2" style="flex:0.9; background:#172232; border-radius:10px; padding:6px 12px; opacity:0;" class="mono">14 m²</span>
      </div>
    </div>
    <div id="h3b-l2" class="abs" style="left:496px; top:820px; width:6px; height:40px; background:#5598FF; transform-origin:50% 0%;"></div>
    <div id="h3b-of" class="card" style="left:88px; top:860px; width:828px; height:362px;">
      <div class="row" style="top:0; font-size:30px; font-weight:700; background:#172232;"><span class="a">Angebot · Familie Petersen</span><span id="h3b-ok" class="pill" style="width:250px; flex:none; opacity:0; background:#317BEE; border-color:#317BEE; color:#fff;">✓ Freigegeben</span></div>
      {''.join(phtml)}
      <div id="h3b-sum" class="row" style="top:286px; height:76px; border-bottom:none; font-weight:700; background:#172232; opacity:0;"><span class="a">Summe netto</span><span class="b" style="font-size:34px;">2.378,00 €</span></div>
    </div>
    <div id="h3b-btn" class="btn" style="left:88px; top:1254px; width:560px; opacity:0;">Angebot freigeben</div>
    <div id="h3b-ring" class="ring" style="left:323px; top:1257px; opacity:0;"></div>
    <div id="h3b-cur" class="abs" style="left:0; top:0; width:56px; height:56px;">{CURSOR_SVG}</div>
"""

fill_t = [0.40, 0.62, 0.84, 1.06]
xl_t = [1.45, 1.55, 1.65]
pos_t = [2.00, 2.18, 2.36]
s2 = [
    '    tl.fromTo("#h3b-title", {opacity:1, scale:1.14, transformOrigin:"0% 50%"}, {opacity:1, scale:1, duration:0.4, ease:"expo.out"}, 0);',
    '    tl.fromTo("#h3b-req", {opacity:0, y:50}, {opacity:1, y:0, duration:0.35, ease:"power3.out"}, 0.08);',
    '    tl.fromTo("#h3b-xl", {opacity:0, y:50}, {opacity:1, y:0, duration:0.35, ease:"power3.out"}, 0.16);',
    '    tl.fromTo("#h3b-of", {opacity:0, y:50}, {opacity:1, y:0, duration:0.35, ease:"power3.out"}, 0.22);',
    '    tl.fromTo("#h3b-l1", {scaleY:0}, {scaleY:1, duration:0.2, ease:"power3.out"}, 1.25);',
    '    tl.fromTo("#h3b-l2", {scaleY:0}, {scaleY:1, duration:0.2, ease:"power3.out"}, 1.80);',
]
for i, t in enumerate(fill_t):
    s2.append(f'    tl.to("#h3b-v{i}", {{opacity:1, duration:0.15}}, {t});')
    s2.append(f'    tl.to("#h3b-f{i}", {{borderColor:"#5598FF", duration:0.15}}, {t});')
for i, t in enumerate(xl_t):
    s2.append(f'    tl.fromTo("#h3b-x{i}", {{opacity:0, y:-24}}, {{opacity:1, y:0, duration:0.2, ease:"power3.out"}}, {t});')
for i, t in enumerate(pos_t):
    s2.append(f'    tl.fromTo("#h3b-p{i}", {{opacity:0, y:-24}}, {{opacity:1, y:0, duration:0.2, ease:"power3.out"}}, {t});')
s2 += [
    '    tl.to("#h3b-sum", {opacity:1, duration:0.25, ease:"power3.out"}, 2.60);',
    '    tl.fromTo("#h3b-btn", {opacity:0, y:30, scale:1, boxShadow:"0 0 0px rgba(85,152,255,0)"}, {opacity:1, y:0, duration:0.3, ease:"power3.out"}, 2.75);',
    '    tl.fromTo("#h3b-cur", {x:860, y:1440, opacity:0}, {x:360, y:1290, opacity:1, duration:0.36, ease:"power3.out"}, 3.00);',
    '    tl.fromTo("#h3b-ring", {opacity:1, scale:0.3}, {opacity:0, scale:1.5, duration:0.35, ease:"power3.out", immediateRender:false}, 3.40);',
    '    tl.to("#h3b-btn", {scale:0.96, boxShadow:"0 0 34px rgba(85,152,255,0.9)", duration:0.08}, 3.40);',
    '    tl.to("#h3b-btn", {scale:1, boxShadow:"0 0 0px rgba(85,152,255,0)", duration:0.2}, 3.50);',
    '    tl.to("#h3b-of", {borderColor:"#5598FF", duration:0.2}, 3.48);',
    '    tl.fromTo("#h3b-ok", {opacity:0, scale:0.7}, {opacity:1, scale:1, duration:0.25, ease:"expo.out"}, 3.50);',
    '    tl.to("#h3b-cur", {opacity:0, duration:0.2}, 3.85);',
]

s3_body, s3_script = end_scene("h3c", "Einmal eingeben. Fertig.")
files = {"h3a": scene("h3a", 3.0, s1_body, "\n".join(s1)),
         "h3b": scene("h3b", 4.5, s2_body, "\n".join(s2)),
         "h3c": scene("h3c", 1.5, s3_body, s3_script)}
d = write_project("h3", files, [("h3a", 0, 3.0), ("h3b", 3.0, 4.5), ("h3c", 7.5, 1.5)])
events = {
    "clack": clacks,
    "alert": [2.55],
    "whoosh": [2.80], "thunk": [[3.0, 80]],
    "read": [round(3.0 + t, 3) for t in fill_t + xl_t + pos_t],
    "glass": [[3.0 + 2.60, 84]],
    "click": [6.40], "thunk2": [[6.40, 70]],
    "chord": [[6.48, [72, 76, 79], 0.6]],
    "endchord": [[7.50, [67, 72, 76], 1.4]],
}
json.dump(events, open(f"{d}/assets/events.json", "w"), indent=1)
print(d)
