"""Gemeinsame Bausteine fuer die Reels H1 bis H4 (HyperFrames)."""
import os, shutil, json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GSAP = os.path.join(ROOT, "lib", "node_modules", "gsap", "dist", "gsap.min.js")

LOGO_SVG = """<svg xmlns="http://www.w3.org/2000/svg" width="160" height="84" viewBox="0 0 160 84">
  <g fill="none" stroke="#5598ff" stroke-width="2" stroke-linejoin="round">
    <path d="M4 11 L42 11 C43.105 11 44 11.895 44 13 L44 51 C44 52.105 43.105 53 42 53 L4 53 C2.895 53 2 52.105 2 51 L2 13 C2 11.895 2.895 11 4 11 Z"/>
    <path d="M61 31 L99 31 C100.105 31 101 31.895 101 33 L101 71 C101 72.105 100.105 73 99 73 L61 73 C59.895 73 59 72.105 59 71 L59 33 C59 31.895 59.895 31 61 31 Z"/>
    <path d="M118 11 L156 11 C157.105 11 158 11.895 158 13 L158 51 C158 52.105 157.105 53 156 53 L118 53 C116.895 53 116 52.105 116 51 L116 13 C116 11.895 116.895 11 118 11 Z"/>
    <path d="M44 32 L59 32"/>
    <path d="M101 32 L116 32"/>
  </g>
</svg>
"""

CURSOR_SVG = ('<svg width="56" height="56" viewBox="0 0 24 24"><path d="M4 2 L4 20 L9 15.5 L12.5 22 '
              'L15.5 20.6 L12.2 14.2 L19 14 Z" fill="#F5F7FA" stroke="#080B12" stroke-width="1.2" '
              'stroke-linejoin="round"/></svg>')

# Basis-Stile, in jeder Szene identisch eingebunden.
BASE_CSS = """
#root { position:absolute; inset:0; background:#080B12; overflow:hidden;
  font-family: Inter, sans-serif; color:#F5F7FA; }
.mono { font-family: 'JetBrains Mono', monospace; }
.abs { position:absolute; }
.hook { position:absolute; left:88px; width:828px; font-weight:700; letter-spacing:-0.02em;
  line-height:1.04; white-space:nowrap; }
.white { color:#F5F7FA; } .blue { color:#5598FF; } .red { color:#FF5A4D; } .muted { color:#A7B4C8; }
.paper { position:absolute; background:#EDF4FF; color:#142031; border-radius:14px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.45); overflow:hidden; }
.paper .ph { font-weight:700; font-size:34px; }
.paper .pl { height:14px; border-radius:7px; background:#C9D6EA; margin-top:16px; }
.card { position:absolute; background:#111824; border:1.5px solid #2B3B52; border-radius:22px; overflow:hidden; }
.row { position:absolute; left:0; right:0; height:70px; display:flex; align-items:center;
  padding:0 26px; font-size:36px; border-bottom:1.5px solid #2B3B52; }
.row .a { flex:1; white-space:nowrap; overflow:hidden; }
.row .b { font-family:'JetBrains Mono', monospace; font-size:32px; margin-left:16px; }
.pill { width:150px; height:46px; border-radius:23px; display:flex; align-items:center;
  justify-content:center; font-size:28px; font-weight:500; margin-left:20px;
  background:#172232; color:#A7B4C8; border:1.5px solid #2B3B52; }
.btn { position:absolute; height:96px; border-radius:22px; background:#317BEE; color:#fff;
  font-size:38px; font-weight:700; display:flex; align-items:center; justify-content:center; }
.badge { position:absolute; height:64px; border-radius:20px; border:1.5px solid #5598FF; color:#5598FF;
  font-size:30px; font-weight:500; display:flex; align-items:center; justify-content:center; }
.ring { position:absolute; width:90px; height:90px; border-radius:50%; border:4px solid #F5F7FA; }
.clock { position:absolute; right:164px; top:232px; height:64px; padding:0 22px; border-radius:20px;
  background:#172232; border:1.5px solid #FF5A4D; font-family:'JetBrains Mono', monospace; font-size:40px;
  display:flex; align-items:center; gap:14px; color:#F5F7FA; }
.clock i { width:14px; height:14px; border-radius:7px; background:#FF5A4D; display:block; }
.bar { position:absolute; left:88px; width:828px; height:14px; border-radius:7px; background:#172232; overflow:hidden; }
.bar b { position:absolute; left:0; top:0; bottom:0; width:828px; background:#FF5A4D; border-radius:7px;
  transform-origin:0 50%; display:block; }
"""


def scene(sid, dur, body, script):
    """Eine Szene als <template>-Datei."""
    return f"""<template>
  <style>{BASE_CSS}</style>
  <div id="root" data-composition-id="{sid}" data-width="1080" data-height="1920" data-duration="{dur}">
{body}
  </div>
  <script>
    (function(){{
    const tl = gsap.timeline({{ paused: true }});
    const $ = (s) => document.querySelector(s);
{script}
    tl.to({{}}, {{ duration: 0.1 }}, {dur} - 0.1);
    window.__timelines = window.__timelines || {{}};
    window.__timelines["{sid}"] = tl;
    }})();
  </script>
</template>
"""


def end_scene(prefix, sentence):
    """Abschluss 7,5 bis 9,0 s: Logo, Satz, Ort, Aufruf."""
    p = prefix
    body = f"""
    <div id="{p}-logo" class="abs" style="left:380px; top:430px; width:320px; height:168px;">
      <img src="assets/systems-mark.svg" style="width:320px; height:168px; display:block;" alt="">
    </div>
    <div id="{p}-word" class="abs" style="left:164px; width:752px; top:630px; text-align:center; font-size:46px; font-weight:500; letter-spacing:-0.025em;">Systemic Automation</div>
    <div id="{p}-sent" class="abs" style="left:164px; width:752px; top:770px; text-align:center; font-size:68px; font-weight:700; letter-spacing:-0.02em; line-height:1.1;">{sentence}</div>
    <div id="{p}-ort" class="abs muted" style="left:164px; width:752px; top:985px; text-align:center; font-size:40px;">Hamburg · 15 Minuten kostenlos</div>
    <div id="{p}-cta" class="btn" style="left:170px; width:740px; top:1090px; height:120px; font-size:52px;">Schreib „PRÜFEN“ per DM</div>
"""
    script = f"""
    tl.fromTo("#{p}-logo", {{opacity:0, y:30}}, {{opacity:1, y:0, duration:0.4, ease:"expo.out"}}, 0);
    tl.fromTo("#{p}-word", {{opacity:0, y:20}}, {{opacity:1, y:0, duration:0.4, ease:"expo.out"}}, 0.08);
    tl.fromTo("#{p}-sent", {{opacity:0, y:24}}, {{opacity:1, y:0, duration:0.4, ease:"power3.out"}}, 0.14);
    tl.fromTo("#{p}-ort", {{opacity:0}}, {{opacity:1, duration:0.35, ease:"power3.out"}}, 0.24);
    tl.fromTo("#{p}-cta", {{opacity:0, scale:0.94}}, {{opacity:1, scale:1, duration:0.4, ease:"expo.out"}}, 0.3);
"""
    return body, script


def index_html(name, scenes):
    hosts = "\n".join(
        f'      <div id="{sid}" data-composition-id="{sid}" data-composition-src="compositions/{sid}.html" '
        f'data-start="{st}" data-duration="{du}" data-track-index="{i+1}" data-track-kind="graphics" '
        f'data-width="1080" data-height="1920"></div>'
        for i, (sid, st, du) in enumerate(scenes))
    return f"""<!doctype html>
<html lang="de" data-resolution="portrait">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=1080, height=1920" />
    <script src="assets/gsap.min.js"></script>
    <style>
      * {{ margin:0; padding:0; box-sizing:border-box; }}
      html, body {{ margin:0; width:1080px; height:1920px; overflow:hidden; background:#080B12; }}
      #bg {{ position:absolute; inset:0; background:#080B12; }}
    </style>
  </head>
  <body>
    <div id="root" data-composition-id="main" data-start="0" data-duration="9" data-width="1080" data-height="1920">
      <div id="bg"></div>
{hosts}
      <audio id="snd" class="clip" src="assets/sound.wav" data-start="0" data-duration="9" data-track-index="9" data-volume="1"></audio>
    </div>
    <script>
      window.__timelines = window.__timelines || {{}};
      window.__timelines["main"] = gsap.timeline({{ paused: true }});
    </script>
  </body>
</html>
"""


def write_project(name, scene_files, scenes):
    d = os.path.join(ROOT, "build", name)
    os.makedirs(os.path.join(d, "compositions"), exist_ok=True)
    os.makedirs(os.path.join(d, "assets"), exist_ok=True)
    shutil.copy(GSAP, os.path.join(d, "assets", "gsap.min.js"))
    with open(os.path.join(d, "assets", "systems-mark.svg"), "w") as f:
        f.write(LOGO_SVG)
    with open(os.path.join(d, "index.html"), "w") as f:
        f.write(index_html(name, scenes))
    for sid, html in scene_files.items():
        with open(os.path.join(d, "compositions", f"{sid}.html"), "w") as f:
            f.write(html)
    with open(os.path.join(d, "hyperframes.json"), "w") as f:
        json.dump({"paths": {"blocks": "compositions", "assets": "assets"}}, f)
    with open(os.path.join(d, "package.json"), "w") as f:
        json.dump({"name": name, "private": True}, f)
    return d
