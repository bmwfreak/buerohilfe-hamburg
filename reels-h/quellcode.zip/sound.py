"""Erzeugt die Tonspur eines Reels (48 kHz, Stereo, 9,0 s) mit numpy. Keine Fremdmusik."""
import json, sys, wave
import numpy as np

SR = 48000
DUR = 9.0
N = int(SR * DUR)
rng = np.random.default_rng(1453)


def env_exp(n, tau):
    return np.exp(-np.arange(n) / (SR * tau))


def lp(x, a):
    """Einpoliger Tiefpass, a in (0,1): groesser = dunkler."""
    y = np.empty_like(x); acc = 0.0
    for i, v in enumerate(x):
        acc = a * acc + (1 - a) * v; y[i] = acc
    return y


def midi_hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def clack():
    n = int(0.025 * SR)
    x = rng.standard_normal(n)
    x = np.diff(np.concatenate([[0], x]))  # hell
    x = lp(x, 0.55) * env_exp(n, 0.006)
    return 0.55 * x


def tick(f=2000, ms=8, amp=0.35):
    n = int(ms / 1000 * SR)
    t = np.arange(n) / SR
    return amp * np.sin(2 * np.pi * f * t) * env_exp(n, ms / 3000)


def thunk(f=80, amp=0.9):
    n = int(0.22 * SR)
    t = np.arange(n) / SR
    fr = f * (1 + 0.6 * np.exp(-t / 0.02))
    ph = 2 * np.pi * np.cumsum(fr) / SR
    x = np.sin(ph) * env_exp(n, 0.06)
    x[:120] += rng.standard_normal(120) * 0.25 * np.linspace(1, 0, 120)
    return amp * x


def glass(m=84, dur=0.4, amp=0.28):
    n = int((dur + 0.3) * SR)
    t = np.arange(n) / SR
    f = midi_hz(m)
    x = sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t / (dur * d))
            for r, a, d in [(1, 1.0, 0.6), (2.0, 0.35, 0.35), (2.76, 0.25, 0.25), (5.4, 0.12, 0.12)])
    att = np.minimum(1, np.arange(n) / (0.003 * SR))
    return amp * x * att


def chord(ms, dur, amp=0.16):
    parts = [glass(m, dur, amp) for m in ms]
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[:len(p)] += p
    return out


def whoosh():
    n = int(0.32 * SR)
    x = rng.standard_normal(n)
    out = np.empty(n); acc = 0.0
    for i in range(n):
        a = 0.97 - 0.5 * np.sin(np.pi * i / n)  # Filter oeffnet und schliesst
        acc = a * acc + (1 - a) * x[i]; out[i] = acc
    e = np.sin(np.pi * np.arange(n) / n) ** 2
    return 0.9 * out * e


def alert():
    out = np.zeros(int(0.26 * SR))
    for k, f in enumerate([880, 660]):
        n = int(0.08 * SR); t = np.arange(n) / SR
        s = 0.22 * np.sin(2 * np.pi * f * t) * np.minimum(1, (n - np.arange(n)) / 400) * np.minimum(1, np.arange(n) / 100)
        st = int(k * 0.12 * SR); out[st:st + n] += s
    return out


def rustle(dur=0.3, amp=0.18):
    n = int(dur * SR)
    x = lp(rng.standard_normal(n), 0.3)
    flutter = lp(np.abs(rng.standard_normal(n)), 0.995)
    e = np.sin(np.pi * np.arange(n) / n)
    return amp * x * flutter / (flutter.max() + 1e-9) * e


def bed():
    beat = 60 / 128
    L = np.zeros(N)
    # Kick auf jedem Viertel, tief und leise
    for k in range(int(DUR / beat) + 1):
        st = int(k * beat * SR); n = int(0.18 * SR)
        t = np.arange(n) / SR
        ph = 2 * np.pi * np.cumsum(50 + 70 * np.exp(-t / 0.03)) / SR
        s = 0.5 * np.sin(ph) * env_exp(n, 0.05)
        L[st:st + n] += s[:max(0, min(n, N - st))]
    # Hi-Hat-Puls auf den Achteln dazwischen
    for k in range(int(DUR / beat) + 1):
        st = int((k + 0.5) * beat * SR); n = int(0.03 * SR)
        if st + n >= N:
            continue
        x = np.diff(np.concatenate([[0], rng.standard_normal(n)])) * env_exp(n, 0.008)
        L[st:st + n] += 0.06 * x
    # Flaeche: Grundton A2 plus Quinte, langsame Huellkurve
    t = np.arange(N) / SR
    pad = 0.12 * np.sin(2 * np.pi * 110 * t) + 0.08 * np.sin(2 * np.pi * 165 * t) + 0.04 * np.sin(2 * np.pi * 220.5 * t)
    pad *= np.minimum(1, t / 1.2) * np.minimum(1, (DUR - t) / 0.6)
    return L + pad


def place(buf, x, t, pan=0.0):
    st = int(t * SR)
    if st >= N:
        return
    x = x[:N - st]
    buf[0, st:st + len(x)] += x * (1 - max(0, pan))
    buf[1, st:st + len(x)] += x * (1 + min(0, pan))


def render(events_path, out_path):
    ev = json.load(open(events_path))
    sfx = np.zeros((2, N))
    for t in ev.get("clack", []):
        place(sfx, clack() * (0.8 + 0.4 * rng.random()), t, pan=rng.uniform(-0.3, 0.3))
    for t in ev.get("clock", []):
        place(sfx, tick(2000, 8, 0.18), t, 0.2)
    for t in ev.get("tick_big", []):
        place(sfx, tick(2000, 10, 0.4), t, 0.2)
    for t in ev.get("rustle", []):
        place(sfx, rustle(), t, rng.uniform(-0.4, 0.4))
    for t in ev.get("scratch", []):
        place(sfx, rustle(0.5, 0.08), t, -0.2)
    for t in ev.get("whoosh", []):
        place(sfx, whoosh(), t)
    for t, f in ev.get("thunk", []) + ev.get("thunk2", []):
        place(sfx, thunk(f), t)
    for k, t in enumerate(ev.get("read", [])):
        place(sfx, tick(3200 + 80 * (k % 4), 6, 0.28), t, 0.15 * ((k % 3) - 1))
    for t, m in ev.get("glass", []):
        place(sfx, glass(m), t)
    for t in ev.get("soft", []):
        place(sfx, tick(1500, 12, 0.2), t)
    for t in ev.get("click", []):
        place(sfx, tick(4000, 4, 0.5), t)
    for t in ev.get("alert", []):
        place(sfx, alert(), t)
    for t, ms, dur in ev.get("chord", []) + ev.get("endchord", []):
        place(sfx, chord(ms, dur), t)
    music = bed()
    # Musikbett rund 12 dB unter den Geraeuschen
    mix = sfx + 0.25 * music[None, :]
    mix /= max(1e-9, np.abs(mix).max()) / 0.8
    pcm = (np.clip(mix, -1, 1) * 32767).astype(np.int16).T
    with wave.open(out_path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(pcm.tobytes())


if __name__ == "__main__":
    render(sys.argv[1], sys.argv[2])
