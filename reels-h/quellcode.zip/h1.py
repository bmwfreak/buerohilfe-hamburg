"""H1: 40 Minuten. Jeden Abend. (Rechnungen auslesen)"""
import json, sys
from common import scene, end_scene, write_project, CURSOR_SVG

SUPPLIERS = [("Müller Bau GmbH", "1.844,50"), ("HansaPrint Hamburg", "411,74"), ("Werkzeug-Kontor", "96,40"),
             ("Farben Lindemann", "238,90"), ("Kfz-Bedarf Elbe", "74,50"), ("Büro-Service HH", "59,00"),
             ("Sanitär Becker", "865,30"), ("Holzhandel Brandt", "1.045,20"), ("Stahlbau Rahlstedt", "2.310,00"),
             ("Reinigung Altona", "180,00"), ("Fliesen-Depot", "522,75"), ("Heizung & Bad Wendt", "689,90")]

# ---------- Szene 1: Hook 0,0 bis 3,0 s ----------
ROT = [-4, 3, -2, 5, -5, 2, -3, 4, -1, 3, -4, 1]
papers = []
for i in range(12):
    off = (11 - i)
    top = i == 11
    inner = ""
    if top:
        inner = ('<div style="padding:38px 42px;">'
                 '<div id="h1a-sup" class="ph" style="font-size:44px;">HansaPrint Hamburg</div>'
                 '<div style="font-size:32px; margin-top:8px; color:#3A4A63;">Rechnung · Hamburg</div>'
                 '<div class="pl" style="width:88%"></div><div class="pl" style="width:70%"></div>'
                 '<div class="pl" style="width:80%"></div>'
                 '<div style="display:flex; justify-content:space-between; margin-top:34px; font-size:40px; font-weight:700;">'
                 '<span>Summe</span><span id="h1a-amt" class="mono">411,74 €</span></div></div>')
    else:
        inner = ('<div style="padding:30px 34px;"><div style="height:22px; width:55%; background:#B7C6DD; border-radius:6px;"></div>'
                 '<div class="pl" style="width:85%"></div><div class="pl" style="width:65%"></div><div class="pl" style="width:75%"></div></div>')
    papers.append(f'<div id="h1a-p{i}" class="paper" style="left:{220 + off*1}px; top:{690 - off*2}px; width:640px; height:420px;">{inner}</div>')

s1_body = f"""
    <div id="h1a-all" class="abs" style="left:0; top:0; width:1080px; height:1920px;">
      <div id="h1a-clock" class="clock"><i></i><span id="h1a-time">21:10</span></div>
      <div id="h1a-l1" class="hook white" style="top:320px; font-size:104px;">40 MINUTEN.</div>
      <div id="h1a-l2" class="hook blue" style="top:430px; font-size:104px;">JEDEN ABEND.</div>
      <div id="h1a-l3" class="hook red" style="top:556px; font-size:60px; font-weight:600;">Rechnungen abtippen.</div>
      <div id="h1a-stack" class="abs" style="left:0; top:0; width:1080px; height:1920px;">
        {''.join(papers)}
      </div>
      <div id="h1a-badge" class="abs" style="left:812px; top:648px; width:104px; height:104px; border-radius:52px; background:#FF5A4D; color:#fff; font-size:46px; font-weight:700; display:flex; align-items:center; justify-content:center;">12</div>
      <div id="h1a-type" class="abs" style="left:88px; top:1160px; width:828px; height:104px; background:#172232; border:1.5px solid #FF5A4D; border-radius:20px; display:flex; align-items:center; padding:0 28px; font-family:'JetBrains Mono', monospace; font-size:40px; color:#F5F7FA;">
        <span id="h1a-typed"></span><span style="display:inline-block; width:4px; height:44px; background:#FF5A4D; margin-left:4px;"></span>
      </div>
      <div id="h1a-prog" class="abs" style="left:88px; top:1300px; font-size:46px; font-weight:500;"><span id="h1a-n">1</span> von 12 abgetippt</div>
      <div class="bar" style="top:1378px;"><b id="h1a-bar"></b></div>
    </div>
"""

segs = [(0.05, 1.20, "HansaPrint Hamburg · 411,74"), (1.36, 2.24, "Werkzeug-Kontor · 96,40"),
        (2.36, 2.76, "Farben Lindem")]
type_lines = []
clacks = []
for a, b, txt in segs:
    n = len(txt)
    for k in range(1, n + 1):
        t = a + (b - a) * (k - 1) / max(n - 1, 1)
        type_lines.append(f'    tl.set("#h1a-typed", {{textContent: {json.dumps(txt[:k])}}}, {t:.3f});')
        if txt[k-1] != " ":
            clacks.append(round(t, 3))

s1_script = "\n".join([
    *[f'    tl.set("#h1a-p{i}", {{rotation:{ROT[i]}}}, 0);' for i in range(12)],
    '    tl.fromTo("#h1a-l1", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0);',
    '    tl.fromTo("#h1a-l2", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0.05);',
    '    tl.fromTo("#h1a-stack", {y:40, scale:0.97}, {y:0, scale:1, duration:2.7, ease:"power3.out"}, 0);',
    '    tl.fromTo("#h1a-badge", {scale:0.6}, {scale:1, duration:0.4, ease:"expo.out"}, 0.1);',
    '    tl.fromTo("#h1a-bar", {scaleX:0.0}, {scaleX:0.08, duration:0.4, ease:"power3.out"}, 0.0);',
    '    tl.set("#h1a-typed", {textContent:""}, 0);',
    *type_lines,
    # Schritt 2
    '    tl.set("#h1a-n", {textContent:"2"}, 1.30); tl.set("#h1a-time", {textContent:"21:13"}, 1.30);',
    '    tl.set("#h1a-typed", {textContent:""}, 1.30);',
    '    tl.set("#h1a-sup", {textContent:"Werkzeug-Kontor"}, 1.30); tl.set("#h1a-amt", {textContent:"96,40 €"}, 1.30);',
    '    tl.fromTo("#h1a-p11", {y:-14}, {y:0, duration:0.3, ease:"power3.out"}, 1.30);',
    '    tl.to("#h1a-bar", {scaleX:0.17, duration:0.4, ease:"power3.out"}, 1.30);',
    '    tl.set("#h1a-clock", {scale:1}, 0); tl.to("#h1a-clock", {scale:1.08, duration:0.05}, 1.30); tl.to("#h1a-clock", {scale:1, duration:0.25, ease:"power3.out"}, 1.35);',
    # Schritt 3
    '    tl.set("#h1a-n", {textContent:"3"}, 2.30); tl.set("#h1a-time", {textContent:"21:16"}, 2.30);',
    '    tl.set("#h1a-typed", {textContent:""}, 2.30);',
    '    tl.set("#h1a-sup", {textContent:"Farben Lindemann"}, 2.30); tl.set("#h1a-amt", {textContent:"238,90 €"}, 2.30);',
    '    tl.fromTo("#h1a-p11", {y:-14}, {y:0, duration:0.3, ease:"power3.out"}, 2.30);',
    '    tl.to("#h1a-bar", {scaleX:0.25, duration:0.4, ease:"power3.out"}, 2.30);',
    '    tl.to("#h1a-clock", {scale:1.08, duration:0.05}, 2.30); tl.to("#h1a-clock", {scale:1, duration:0.25, ease:"power3.out"}, 2.35);',
    # Abgang nach oben
    '    tl.to("#h1a-all", {y:-220, opacity:0, duration:0.18, ease:"power3.in"}, 2.80);',
])

# ---------- Szene 2: Automatisch 3,0 bis 7,5 s ----------
rows = []
for i, (s, b) in enumerate(SUPPLIERS):
    rows.append(f'<div id="h1b-r{i}" class="row" style="top:{i*84}px; height:84px; font-size:38px;"><span class="a">{s.replace("&", "&amp;")}</span>'
                f'<span class="b" style="font-size:36px;">{b}</span><span id="h1b-s{i}" class="pill" style="width:140px; height:50px;">Prüfen</span></div>')

s2_body = f"""
    <div id="h1b-title" class="hook blue" style="top:220px; font-size:110px;">Automatisch.</div>
    <div id="h1b-inv" class="paper" style="left:88px; top:390px; width:430px; height:290px;">
      <div style="padding:26px 30px; position:relative;">
        <div class="ph" style="font-size:32px;">Müller Bau GmbH</div>
        <div style="font-size:28px; margin-top:6px; color:#3A4A63;">Rechnung · Hamburg</div>
        <div class="pl" style="width:85%"></div><div class="pl" style="width:68%"></div>
        <div style="display:flex; justify-content:space-between; margin-top:24px; font-size:30px; font-weight:700;">
          <span>Summe</span><span class="mono">1.844,50 €</span></div>
      </div>
      <div id="h1b-f1" class="abs" style="left:18px; top:16px; width:330px; height:54px; border:3px solid #5598FF; border-radius:10px;"></div>
      <div id="h1b-f2" class="abs" style="left:194px; top:180px; width:220px; height:54px; border:3px solid #5598FF; border-radius:10px;"></div>
      <div id="h1b-scan" class="abs" style="left:0; top:0; width:430px; height:6px; background:#5598FF;"></div>
    </div>
    <div id="h1b-cw" class="abs" style="left:560px; top:430px; width:356px;">
      <div class="mono" style="font-size:64px; white-space:nowrap;"><span id="h1b-cnt">0</span> von 12</div>
      <div class="muted" style="font-size:38px; margin-top:6px;">ausgelesen</div>
    </div>
    <div id="h1b-list" class="card" style="left:88px; top:720px; width:828px; height:562px;">
      <div class="row muted" style="top:0; font-size:28px; background:#172232;"><span class="a">Eingang · Lieferant</span><span style="margin-right:170px;">Betrag</span><span>Status</span></div>
      <div class="abs" style="left:0; top:70px; width:828px; height:420px; overflow:hidden;" data-layout-allow-overflow>
        <div id="h1b-rows" class="abs" style="left:0; top:0; width:828px; height:1008px;">{''.join(rows)}</div>
      </div>
      <div id="h1b-sum" class="row" style="top:490px; height:72px; border-bottom:none; font-weight:700; background:#172232;"><span class="a">Summe</span><span class="b" style="font-size:34px;">8.338,19 €</span></div>
    </div>
    <div id="h1b-btn" class="btn" style="left:88px; top:1314px; width:470px; opacity:0;">Alle freigeben</div>
    <div id="h1b-exp" class="badge" style="left:590px; top:1330px; width:300px; opacity:0;">Excel · CSV</div>
    <div id="h1b-ring" class="ring" style="left:278px; top:1317px; opacity:0;"></div>
    <div id="h1b-cur" class="abs" style="left:0; top:0; width:56px; height:56px;">{CURSOR_SVG}</div>
"""

row_t = [0.62 + i * 0.17 for i in range(12)]
s2 = [
    '    tl.fromTo("#h1b-title", {opacity:1, scale:1.14, transformOrigin:"0% 50%"}, {opacity:1, scale:1, duration:0.4, ease:"expo.out"}, 0);',
    '    tl.fromTo("#h1b-inv", {opacity:0, y:60}, {opacity:1, y:0, duration:0.35, ease:"power3.out"}, 0.08);',
    '    tl.fromTo("#h1b-list", {opacity:0, y:80}, {opacity:1, y:0, duration:0.4, ease:"power3.out"}, 0.16);',
    '    tl.fromTo("#h1b-scan", {y:0, opacity:1}, {y:284, duration:0.6, ease:"none"}, 0.25);',
    '    tl.to("#h1b-scan", {opacity:0, duration:0.1}, 0.86);',
    '    tl.fromTo("#h1b-f1", {opacity:0}, {opacity:1, duration:0.15}, 0.42);',
    '    tl.fromTo("#h1b-f2", {opacity:0}, {opacity:1, duration:0.15}, 0.72);',
    *[f'    tl.fromTo("#h1b-r{i}", {{opacity:0, x:90}}, {{opacity:1, x:0, duration:0.16, ease:"expo.out"}}, {t:.2f});' for i, t in enumerate(row_t)],
    *[f'    tl.set("#h1b-cnt", {{textContent:"{i+1}"}}, {t:.2f});' for i, t in enumerate(row_t)],
    *[f'    tl.to("#h1b-rows", {{y:{-(i-4)*84}, duration:0.13, ease:"power3.out"}}, {t:.2f});' for i, t in enumerate(row_t) if i >= 5],
    *[f'    tl.to("#h1b-r{i-5}", {{opacity:0, duration:0.1}}, {t:.2f});' for i, t in enumerate(row_t) if i >= 5],
    '    tl.fromTo("#h1b-sum", {opacity:0}, {opacity:1, duration:0.25, ease:"power3.out"}, 2.80);',
    '    tl.fromTo("#h1b-btn", {opacity:0, y:30, scale:1, boxShadow:"0 0 0px rgba(85,152,255,0)"}, {opacity:1, y:0, duration:0.3, ease:"power3.out"}, 2.95);',
    '    tl.fromTo("#h1b-cw", {opacity:0, x:40}, {opacity:1, x:0, duration:0.3, ease:"power3.out"}, 0.12);',
        '    tl.fromTo("#h1b-cur", {x:860, y:1500, opacity:0}, {x:300, y:1344, opacity:1, duration:0.38, ease:"power3.out"}, 3.42);',
    '    tl.fromTo("#h1b-ring", {opacity:1, scale:0.3}, {opacity:0, scale:1.5, duration:0.35, ease:"power3.out", immediateRender:false}, 3.82);',
    '    tl.to("#h1b-btn", {scale:0.96, boxShadow:"0 0 34px rgba(85,152,255,0.9)", duration:0.08}, 3.82);',
    '    tl.to("#h1b-btn", {scale:1, boxShadow:"0 0 0px rgba(85,152,255,0)", duration:0.2}, 3.92);',
    *[f'    tl.to("#h1b-s{i}", {{backgroundColor:"#5598FF", borderColor:"#5598FF", color:"#FFFFFF", duration:0.12}}, {3.88 + (i-7)*0.04 if i >= 7 else 3.88:.3f});' for i in range(12)],
    *[f'    tl.set("#h1b-s{i}", {{textContent:"✓ Frei"}}, {3.88 + (i-7)*0.04 if i >= 7 else 3.88:.3f});' for i in range(12)],
    '    tl.fromTo("#h1b-exp", {opacity:0, x:-20}, {opacity:1, x:0, duration:0.3, ease:"power3.out"}, 4.08);',
    '    tl.to("#h1b-cur", {opacity:0, duration:0.2}, 4.25);',
]

s3_body, s3_script = end_scene("h1c", "Abends wieder frei.")

files = {
    "h1a": scene("h1a", 3.0, s1_body, s1_script),
    "h1b": scene("h1b", 4.5, s2_body, "\n".join(s2)),
    "h1c": scene("h1c", 1.5, s3_body, s3_script),
}
d = write_project("h1", files, [("h1a", 0, 3.0), ("h1b", 3.0, 4.5), ("h1c", 7.5, 1.5)])

# Ton-Ereignisse (absolute Sekunden)
events = {
    "clack": clacks,
    "clock": [0.0, 0.5, 1.0, 1.5, 2.0, 2.5],
    "tick_big": [1.30, 2.30],
    "whoosh": [2.80],
    "thunk": [[3.0, 80]],
    "read": [round(3.0 + t, 3) for t in row_t],
    "glass": [[3.0 + row_t[-1], 84]],
    "soft": [5.80],
    "click": [6.82],
    "thunk2": [[6.82, 70]],
    "chord": [[6.90, [72, 76, 79], 0.6]],
    "endchord": [[7.50, [67, 72, 76], 1.4]],
}
json.dump(events, open(f"{d}/assets/events.json", "w"), indent=1)
print(d)
