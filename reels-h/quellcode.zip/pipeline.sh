#!/bin/bash
# Aufruf: pipeline.sh h1 [check|render|all]
set -e
R=$(cd "$(dirname "$0")/.." && pwd)
NAME=$1; STEP=${2:-all}
export HYPERFRAMES_BROWSER_PATH=/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell
export HYPERFRAMES_NO_TELEMETRY=1 HYPERFRAMES_NO_UPDATE_CHECK=1 HYPERFRAMES_SKIP_SKILLS=1
HF="npx --yes hyperframes@0.8.145"
cd "$R/src"
D=$(python3 "$NAME.py")
cd "$D"
if [ "$STEP" = check ] || [ "$STEP" = all ]; then
  python3 "$R/src/sound.py" assets/events.json assets/raw0.wav
  ffmpeg -hide_banner -loglevel error -y -i assets/raw0.wav -af "alimiter=limit=0.22:attack=1:release=60:level=false" assets/raw.wav && rm -f assets/raw0.wav
  J=$(ffmpeg -hide_banner -i assets/raw.wav -af loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json -f null - 2>&1 | sed -n '/^{/,/^}/p')
  MI=$(echo "$J" | python3 -c "import json,sys;print(json.load(sys.stdin)['input_i'])")
  MTP=$(echo "$J" | python3 -c "import json,sys;print(json.load(sys.stdin)['input_tp'])")
  MLRA=$(echo "$J" | python3 -c "import json,sys;print(json.load(sys.stdin)['input_lra'])")
  MTH=$(echo "$J" | python3 -c "import json,sys;print(json.load(sys.stdin)['input_thresh'])")
  ffmpeg -hide_banner -loglevel error -y -i assets/raw.wav -af "loudnorm=I=-16:TP=-1.5:LRA=7:measured_I=$MI:measured_TP=$MTP:measured_LRA=$MLRA:measured_thresh=$MTH:linear=true,aresample=48000" -ar 48000 -ac 2 assets/sound.wav
  rm -f assets/raw.wav
  $HF check --json > check.json 2>/dev/null || true
  python3 - <<'EOF'
import json
d=json.load(open("check.json"))
def walk(x,acc):
    if isinstance(x,dict):
        if x.get("severity") in ("error","warning"): acc.append(x)
        for v in x.values(): walk(v,acc)
    elif isinstance(x,list):
        for v in x: walk(v,acc)
acc=[]; walk(d,acc)
print("CHECK ok=",d.get("ok"), "findings:",len(acc))
for a in acc[:40]:
    print(" -",a.get("severity"),a.get("code") or a.get("rule"),"|",(a.get("message") or "")[:200],"|",a.get("selector") or a.get("elementId") or "", a.get("time") or "")
EOF
fi
if [ "$STEP" = render ] || [ "$STEP" = all ]; then
  mkdir -p renders
  $HF render --fps 60 --quality high -o renders/$NAME.mp4 2>&1 | grep -E "Render complete|rror" | tail -3
  ffmpeg -hide_banner -loglevel error -y -i renders/$NAME.mp4 -i assets/sound.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -ar 48000 -movflags +faststart renders/$NAME.tmp.mp4 && mv renders/$NAME.tmp.mp4 renders/$NAME.mp4
  ffprobe -v error -select_streams v:0 -show_entries stream=width,height,r_frame_rate,codec_name -show_entries format=duration -of compact renders/$NAME.mp4
  ffmpeg -hide_banner -nostats -i renders/$NAME.mp4 -af ebur128=peak=true -f null - 2>&1 | grep -A12 "Summary" | grep -E "I:|Peak:|True" | tr -s ' '
  # Kontaktbogen
  mkdir -p sheet; rm -f sheet/*.png
  i=0
  for t in 0.0 0.5 1.0 2.0 3.0 3.5 4.5 5.5 6.5 7.0 8.0 8.9; do
    i=$((i+1)); n=$(printf %02d $i)
    ffmpeg -hide_banner -loglevel error -y -ss $t -i renders/$NAME.mp4 -frames:v 1 -vf "scale=360:640,drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text='${t} s':x=10:y=10:fontsize=28:fontcolor=white:box=1:boxcolor=black@0.7" sheet/$n.png
  done
  ffmpeg -hide_banner -loglevel error -y -i sheet/%02d.png -vf tile=4x3:padding=6:color=0x333333 kontaktbogen.png
  ffmpeg -hide_banner -loglevel error -y -ss 0.5 -i renders/$NAME.mp4 -frames:v 1 cover-0_5s.png
  echo "SHEET $D/kontaktbogen.png"
fi
