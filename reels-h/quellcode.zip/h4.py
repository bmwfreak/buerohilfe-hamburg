"""H4: Zeile fuer Zeile. Eine Stunde. (Lieferschein und Rechnung abgleichen)"""
import json
from common import scene, end_scene, write_project, CURSOR_SVG

ITEMS = [("Kabel NYM 3x1,5", "100 m", "100 m"), ("Schalter weiß", "24", "24"), ("Steckdose", "36", "36"),
         ("Kabelkanal 40x60", "10", "12"), ("Dose UP", "50", "50"), ("Klemme 3-fach", "200", "200")]
DEV = 3


def doc(prefix, title, col, left):
    rows = "".join(
        f'<div style="display:flex; justify-content:space-between; height:56px; align-items:center; border-bottom:1.5px solid #C9D6EA; font-size:28px;">'
        f'<span style="white-space:nowrap;">{n}</span><span class="mono" style="font-weight:700;">{a if col == 1 else b}</span></div>'
        for n, a, b in ITEMS)
    grey = "".join('<div class="pl" style="width:%d%%; margin-top:14px;"></div>' % w for w in (88, 72, 80, 64, 84))
    return (f'<div id="{prefix}" class="paper" style="left:{left}px; top:700px; width:404px; height:560px; padding:22px 24px;">'
            f'<div style="font-weight:700; font-size:32px; margin-bottom:8px;">{title}</div>{rows}{grey}</div>')


s1_body = f"""
    <div id="h4a-all" class="abs" style="left:0; top:0; width:1080px; height:1920px;">
      <div id="h4a-clock" class="clock"><i></i><span id="h4a-time">16:05</span></div>
      <div id="h4a-l1" class="hook white" style="top:320px; font-size:104px;">ZEILE FÜR</div>
      <div id="h4a-l2" class="hook white" style="top:428px; font-size:104px;">ZEILE.</div>
      <div id="h4a-l3" class="hook blue" style="top:536px; font-size:104px;">EINE STUNDE.</div>
      {doc("h4a-ls", "Lieferschein", 1, 88)}
      {doc("h4a-re", "Rechnung", 2, 512)}
      <div id="h4a-rule" class="abs" style="left:80px; top:770px; width:844px; height:60px; border-radius:10px; background:rgba(255,90,77,0.18); border:3px solid #FF5A4D;"></div>
      <div id="h4a-prog" class="abs" style="left:88px; top:1296px; font-size:46px; font-weight:500;">Zeile <span id="h4a-n">1</span> von 18</div>
      <div class="bar" style="top:1372px;"><b id="h4a-bar"></b></div>
    </div>
"""

STEP = [0.8, 1.6, 2.4]
CLOCK = ["16:08", "16:12", "16:15"]
s1 = ['    tl.fromTo("#h4a-l1", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0);',
      '    tl.fromTo("#h4a-l2", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0.04);',
      '    tl.fromTo("#h4a-l3", {x:-26}, {x:0, duration:0.6, ease:"power3.out"}, 0.08);',
      '    tl.fromTo("#h4a-rule", {x:-30, opacity:0.4}, {x:0, opacity:1, duration:0.5, ease:"power3.out"}, 0);',
      '    tl.fromTo("#h4a-bar", {scaleX:0}, {scaleX:0.056, duration:0.3, ease:"power3.out"}, 0);',
      '    tl.set("#h4a-clock", {scale:1}, 0);']
for k, t in enumerate(STEP):
    s1 += [f'    tl.to("#h4a-rule", {{y:{56*(k+1)}, duration:0.5, ease:"power3.inOut"}}, {t - 0.35:.2f});',
           f'    tl.set("#h4a-n", {{textContent:"{k+2}"}}, {t}); tl.set("#h4a-time", {{textContent:"{CLOCK[k]}"}}, {t});',
           f'    tl.to("#h4a-bar", {{scaleX:{(k+2)/18:.3f}, duration:0.3, ease:"power3.out"}}, {t});',
           f'    tl.to("#h4a-clock", {{scale:1.08, duration:0.05}}, {t}); tl.to("#h4a-clock", {{scale:1, duration:0.25, ease:"power3.out"}}, {t + 0.06:.2f});']
s1.append('    tl.to("#h4a-all", {y:-220, opacity:0, duration:0.18, ease:"power3.in"}, 2.80);')

# ---------- Szene 2 ----------
rows = []
for i, (n, a, b) in enumerate(ITEMS):
    dev = i == DEV
    rows.append(
        f'<div id="h4b-r{i}" class="row" style="top:{70 + i*76}px; height:76px; font-size:34px; opacity:0;'
        + (' color:#FF5A4D;' if dev else '') + '">'
        f'<span class="a">{n}</span><span class="mono" style="width:130px; text-align:right; font-size:32px;">{a}</span>'
        f'<span class="mono" style="width:130px; text-align:right; font-size:32px;">{b}</span>'
        + (f'<span id="h4b-open" class="pill" style="width:120px; margin-left:18px; opacity:0; border-color:#5598FF; color:#5598FF;">offen</span>'
           f'<span id="h4b-warn" style="width:120px; margin-left:-120px; text-align:center; font-weight:700; font-size:34px;">≠</span>' if dev else
           f'<span id="h4b-c{i}" style="width:44px; height:44px; border-radius:22px; border:2px solid #2B3B52; margin-left:18px; margin-right:76px; '
           f'display:flex; align-items:center; justify-content:center; font-size:28px; color:#fff;"><span id="h4b-k{i}" style="opacity:0">✓</span></span>')
        + '</div>')

s2_body = f"""
    <div id="h4b-title" class="hook blue" style="top:220px; font-size:110px;">Automatisch.</div>
    <div id="h4b-cw" class="abs" style="left:88px; top:372px; width:828px; white-space:nowrap;">
      <span class="mono" style="font-size:56px;"><span id="h4b-cnt">0</span> von 18</span>
      <span class="muted" style="font-size:38px; margin-left:12px;">verglichen</span>
      <span id="h4b-dev" class="red" style="font-size:38px; font-weight:700; margin-left:18px; opacity:0;">· 1 Abweichung</span>
    </div>
    <div id="h4b-list" class="card" style="left:88px; top:470px; width:828px; height:592px;">
      <div class="row muted" style="top:0; font-size:28px; background:#172232;"><span class="a">Position</span><span style="width:130px; text-align:right;">Liefer.</span><span style="width:130px; text-align:right;">Rechn.</span><span style="width:138px;"></span></div>
      {''.join(rows)}
      <div id="h4b-dbox" class="abs" style="left:6px; top:{70 + DEV*76 + 4}px; width:816px; height:68px; border:3px dashed #FF5A4D; border-radius:12px; opacity:0;"></div>
      <div id="h4b-more" class="row muted" style="top:526px; height:66px; font-size:30px; border-bottom:none; opacity:0;"><span class="a">+ 12 weitere Positionen passen</span></div>
    </div>
    <div id="h4b-b1" class="btn" style="left:88px; top:1094px; width:404px; opacity:0;">Später klären</div>
    <div id="h4b-b2" class="btn" style="left:512px; top:1094px; width:404px; background:#172232; border:1.5px solid #2B3B52; color:#F5F7FA; opacity:0;">Übernehmen</div>
    <div id="h4b-you" class="abs" style="left:88px; top:1226px; width:828px; font-size:60px; font-weight:700; opacity:0;">Du entscheidest.</div>
    <div id="h4b-ring" class="ring" style="left:245px; top:1097px; opacity:0;"></div>
    <div id="h4b-cur" class="abs" style="left:0; top:0; width:56px; height:56px;">{CURSOR_SVG}</div>
"""

row_t = [0.45 + i * 0.16 for i in range(6)]
fast = [1.45 + k * 0.06 for k in range(12)]
s2 = [
    '    tl.fromTo("#h4b-title", {opacity:1, scale:1.14, transformOrigin:"0% 50%"}, {opacity:1, scale:1, duration:0.4, ease:"expo.out"}, 0);',
    '    tl.fromTo("#h4b-cw", {opacity:0, x:40}, {opacity:1, x:0, duration:0.3, ease:"power3.out"}, 0.10);',
    '    tl.fromTo("#h4b-list", {opacity:0, y:60}, {opacity:1, y:0, duration:0.35, ease:"power3.out"}, 0.16);',
]
for i, t in enumerate(row_t):
    s2.append(f'    tl.fromTo("#h4b-r{i}", {{opacity:0, x:70}}, {{opacity:1, x:0, duration:0.18, ease:"expo.out"}}, {t:.2f});')
    s2.append(f'    tl.set("#h4b-cnt", {{textContent:"{i+1}"}}, {t + 0.12:.2f});')
    if i != DEV:
        s2.append(f'    tl.to("#h4b-c{i}", {{backgroundColor:"#317BEE", borderColor:"#317BEE", duration:0.1}}, {t + 0.12:.2f});')
        s2.append(f'    tl.to("#h4b-k{i}", {{opacity:1, duration:0.1}}, {t + 0.12:.2f});')
    else:
        s2.append(f'    tl.fromTo("#h4b-dbox", {{opacity:0, scale:1.04}}, {{opacity:1, scale:1, duration:0.25, ease:"expo.out"}}, {t + 0.12:.2f});')
for k, t in enumerate(fast):
    s2.append(f'    tl.set("#h4b-cnt", {{textContent:"{7+k}"}}, {t:.2f});')
s2 += [
    '    tl.fromTo("#h4b-more", {opacity:0}, {opacity:1, duration:0.25}, 1.50);',
    f'    tl.fromTo("#h4b-dev", {{opacity:0}}, {{opacity:1, duration:0.2}}, {fast[-1] + 0.05:.2f});',
    '    tl.fromTo("#h4b-b1", {opacity:0, y:30, scale:1, boxShadow:"0 0 0px rgba(85,152,255,0)"}, {opacity:1, y:0, duration:0.3, ease:"power3.out"}, 2.55);',
    '    tl.fromTo("#h4b-b2", {opacity:0, y:30}, {opacity:1, y:0, duration:0.3, ease:"power3.out"}, 2.62);',
    '    tl.fromTo("#h4b-cur", {x:860, y:1420, opacity:0}, {x:290, y:1125, opacity:1, duration:0.36, ease:"power3.out"}, 2.95);',
    '    tl.fromTo("#h4b-ring", {opacity:1, scale:0.3}, {opacity:0, scale:1.5, duration:0.35, ease:"power3.out", immediateRender:false}, 3.38);',
    '    tl.to("#h4b-b1", {scale:0.96, boxShadow:"0 0 34px rgba(85,152,255,0.9)", duration:0.08}, 3.38);',
    '    tl.to("#h4b-b1", {scale:1, boxShadow:"0 0 0px rgba(85,152,255,0)", duration:0.2}, 3.48);',
    '    tl.to("#h4b-dbox", {borderColor:"#5598FF", duration:0.2}, 3.46);',
    '    tl.to("#h4b-warn", {opacity:0, duration:0.1}, 3.46);',
    '    tl.fromTo("#h4b-open", {opacity:0, scale:0.7}, {opacity:1, scale:1, duration:0.25, ease:"expo.out"}, 3.48);',
    '    tl.fromTo("#h4b-you", {opacity:0, y:20}, {opacity:1, y:0, duration:0.3, ease:"power3.out"}, 3.55);',
    '    tl.to("#h4b-cur", {opacity:0, duration:0.2}, 3.90);',
]

s3_body, s3_script = end_scene("h4c", "Die Stunde gehört wieder dir.")
files = {"h4a": scene("h4a", 3.0, s1_body, "\n".join(s1)),
         "h4b": scene("h4b", 4.5, s2_body, "\n".join(s2)),
         "h4c": scene("h4c", 1.5, s3_body, s3_script)}
d = write_project("h4", files, [("h4a", 0, 3.0), ("h4b", 3.0, 4.5), ("h4c", 7.5, 1.5)])
events = {
    "clock": [0.0, 0.5, 1.0, 1.5, 2.0, 2.5],
    "tick_big": STEP,
    "scratch": [0.1] + [round(t - 0.35, 2) for t in STEP],
    "whoosh": [2.80], "thunk": [[3.0, 80]],
    "read": [round(3.0 + t + 0.12, 3) for i, t in enumerate(row_t) if i != DEV] + [round(3.0 + t, 3) for t in fast],
    "alert": [round(3.0 + row_t[DEV] + 0.12, 3)],
    "glass": [[round(3.0 + fast[-1], 3), 84]],
    "click": [6.38], "thunk2": [[6.38, 70]],
    "chord": [[6.46, [72, 76, 79], 0.6]],
    "endchord": [[7.50, [67, 72, 76], 1.4]],
}
json.dump(events, open(f"{d}/assets/events.json", "w"), indent=1)
print(d)
